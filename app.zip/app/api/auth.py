from fastapi import APIRouter, Depends, HTTPException, status, Request
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy.orm import Session
try:
    from jose import jwt, JWTError
    _JOSE_AVAILABLE = True
except Exception:
    jwt = None
    JWTError = Exception
    _JOSE_AVAILABLE = False
from passlib.context import CryptContext
from datetime import datetime, timedelta
import os

from app.core.database import SessionLocal
from app.models.user import User
from app.models.user_role import UserRole
from app.models.role import Role
from app.models.role_permission import RolePermission
from app.models.permission import Permission
from app.models.college import College

SECRET_KEY = os.getenv("SECRET_KEY", "CHANGE_ME_REPLACE")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

router = APIRouter(prefix="/auth", tags=["Auth"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class LoginRequest(BaseModel):
    email: str
    password: str


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    if not _JOSE_AVAILABLE:
        raise HTTPException(status_code=500, detail="Missing required dependency 'python-jose'. Please install python-jose.")
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def create_refresh_token(data: dict):
    if not _JOSE_AVAILABLE:
        raise HTTPException(status_code=500, detail="Missing required dependency 'python-jose'. Please install python-jose.")
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def load_user_role(db: Session, user_id: int) -> Optional[Role]:
    ur = db.query(UserRole).filter(UserRole.user_id == user_id, UserRole.status == 1).order_by(UserRole.role_id).first()
    if not ur:
        return None
    return db.query(Role).filter(Role.role_id == ur.role_id, Role.status == 1).first()


def load_permissions_for_user(db: Session, user_id: int) -> List[str]:
    # Get active roles for user
    role_ids = [r.role_id for r in db.query(UserRole.role_id).filter(UserRole.user_id == user_id, UserRole.status == 1).all()]
    if not role_ids:
        return []
    perms = (
        db.query(Permission.permission_code)
        .join(RolePermission, RolePermission.permission_id == Permission.permission_id)
        .filter(RolePermission.role_id.in_(role_ids), RolePermission.status == 1, Permission.status == 1)
        .all()
    )
    return list({p[0] for p in perms})


@router.post("/login")
def login(data: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or user.status != 1:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    role = load_user_role(db, user.user_id)
    permissions = load_permissions_for_user(db, user.user_id)

    payload = {
        "user_id": user.user_id,
        "role_id": role.role_id if role else None,
        "college_id": user.college_id,
        "permissions": permissions,
    }

    access_token = create_access_token(payload)
    refresh_token = create_refresh_token(payload)

    college = db.query(College).filter(College.college_id == user.college_id).first()
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "user": {
            "user_id": user.user_id,
            "name": user.username,
            "email": user.email,
            "role_id": role.role_id if role else None,
            "role_name": role.role_name if role else None,
            "college_id": user.college_id,
            "college_name": college.college_name if college else None
        },
        "permissions": permissions,
    }


class RefreshRequest(BaseModel):
    refresh_token: str


@router.post("/refresh")
def refresh_token(data: RefreshRequest):
    try:
        if not _JOSE_AVAILABLE:
            raise HTTPException(status_code=500, detail="Missing required dependency 'python-jose'. Please install python-jose.")
        payload = jwt.decode(data.refresh_token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

    token_payload = {
        "user_id": payload.get("user_id"),
        "role_id": payload.get("role_id"),
        "college_id": payload.get("college_id"),
        "permissions": payload.get("permissions", []),
    }
    return {"access_token": create_access_token(token_payload)}


def require_permissions(permission_codes: List[str]):
    def dependency(request: Request, db: Session = Depends(get_db)):
        auth = request.headers.get("Authorization")
        if not auth or not auth.startswith("Bearer "):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
        token = auth.split(" ", 1)[1]
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        except JWTError:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

        role_id = payload.get("role_id")
        permissions = payload.get("permissions", []) or []

        # Super Admin bypass
        if role_id:
            r = db.query(Role).filter(Role.role_id == role_id, Role.status == 1).first()
            if r and r.role_name and r.role_name.lower() == "super admin":
                return

        if not all(p in permissions for p in permission_codes):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Permission denied")

    return dependency
